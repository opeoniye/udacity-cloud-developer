README

Institution:	Udacity
Course:			Cloud Developer Nanodegree
project id:		Project 1
Project topic:	Deploy Static Website on AWS

S3 Bucket:		bams-udacity-project1

S3 website endpoint: http://bams-udacity-project1.s3-website-us-east-1.amazonaws.com/

Cloudfront endpoint:
https://d3b7eicwzkiihx.cloudfront.net